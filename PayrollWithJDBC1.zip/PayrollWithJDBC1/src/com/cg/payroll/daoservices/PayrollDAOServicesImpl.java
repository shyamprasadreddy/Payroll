package com.cg.payroll.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.utility.PayrollUtility;

public class PayrollDAOServicesImpl implements PayrollDAOServices {
	public static HashMap<Integer, Associate>associates=new HashMap<>();
	
	private Connection con=null;
	public PayrollDAOServicesImpl() throws PayrollServicesDownException {
	con = PayrollUtility.getDBConnection();	
	}
	

	@Override
	public int insertAssociate(Associate associate) throws SQLException  {
		try {
			con.setAutoCommit(false);
			PreparedStatement ps1=con.prepareStatement("insert into Associate(yearlyInvestmentUnder80C,firstName,lastName,department,designation,pancard,emailId) value(?,?,?,?,?,?,?)");
			ps1.setInt(1, associate.getYearlyInvestmentUnder80C());
			ps1.setString(2, associate.getFirstName());
			ps1.setString(3, associate.getLastName());
			ps1.setString(4, associate.getDepartment());
			ps1.setString(5, associate.getDesignation());
			ps1.setString(6, associate.getPancard());
			ps1.setString(7, associate.getEmailId());
			ps1.executeUpdate();
			
			PreparedStatement ps2=con.prepareStatement("select max(associateID) from Associate");
			ResultSet rs=ps2.executeQuery();
			rs.next();
			int associateID=rs.getInt(1);
			
			PreparedStatement ps3=con.prepareStatement("insert into Salary(associateID,basicSalary,epf,companyPf) value(?,?,?,?)");
			ps3.setInt(1, associateID);
			ps3.setInt(2, (int) associate.getSalary().getBasicSalary());
			ps3.setLong(3, (long) associate.getSalary().getEpf());
			ps3.setFloat(4, associate.getSalary().getCompanyPf());
			ps3.executeUpdate();
			
			PreparedStatement ps4=con.prepareStatement("insert into BankDetails(associateID,accountNumber,bankName,ifscCode)value(?,?,?,?)");
			ps4.setInt(1, associateID);
			ps4.setInt(2, associate.getBankDetails().getAccountNumber());
			ps4.setString(3, associate.getBankDetails().getBankName());
			ps4.setString(4, associate.getBankDetails().getIfscCode());
			ps4.executeUpdate();
			
			con.commit();
			return associateID;
		} catch (SQLException e) {
			con.rollback();
			throw e;
		}
		finally {
			con.setAutoCommit(true);
		}
		

	}
	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
		try {
			con.setAutoCommit(false);
						
			PreparedStatement ps1=con.prepareStatement("update Associate set yearlyInvestmentUnder80C=?,firstName=?,lastName=?,department=?,designation=?,pancard=?,emailId=? where associateID=?");
			ps1.setInt(1, associate.getYearlyInvestmentUnder80C());
			ps1.setString(2, associate.getFirstName());
			ps1.setString(3, associate.getLastName());
			ps1.setString(4, associate.getDepartment());
			ps1.setString(5, associate.getDesignation());
			ps1.setString(6, associate.getPancard());
			ps1.setString(7, associate.getEmailId());
			ps1.setInt(8, associate.getAssociateID());
			ps1.executeUpdate();
						
			PreparedStatement ps3=con.prepareStatement("update Salary set basicSalary=?,hra=?,conveyenceAllowance=?,otherAllowance=?,personalAllowance=?,monthlyTax=?,epf=?,companyPf=?,gratuity=?,grossSalary=?,netSalary=? where associateID=?");
			ps3.setFloat(1, associate.getSalary().getBasicSalary());
			ps3.setFloat(2, associate.getSalary().getHra());
			ps3.setFloat(3, associate.getSalary().getConveyenceAllowance());
			ps3.setFloat(4, associate.getSalary().getOtherAllowance());
			ps3.setFloat(5, associate.getSalary().getPersonalAllowance());
			ps3.setFloat(6, associate.getSalary().getMonthlyTax());
			ps3.setFloat(7, associate.getSalary().getEpf());
			ps3.setFloat(8, associate.getSalary().getCompanyPf());
			ps3.setFloat(9, associate.getSalary().getGratuity());
			ps3.setFloat(10, associate.getSalary().getGrossSalary());
			ps3.setFloat(11, associate.getSalary().getNetSalary());
			ps3.setInt(12, associate.getAssociateID());
			ps3.executeUpdate();
			
			PreparedStatement ps4=con.prepareStatement("update BankDetails set accountNumber=?,bankName=?,ifscCode=? where associateID=?");			
			ps4.setInt(1, associate.getBankDetails().getAccountNumber());
			ps4.setString(2, associate.getBankDetails().getBankName());
			ps4.setString(3, associate.getBankDetails().getIfscCode());
			ps4.setInt(4, associate.getAssociateID());
			ps4.executeUpdate();
			
			con.commit();
			return true;
		} catch (SQLException e) {
			con.rollback();
			throw e;
		}
		
		finally {
			con.setAutoCommit(true);
		}
		
		
	

	}
	@Override
	public boolean deleteAssociate(int associateId) throws SQLException {
		try {
		con.setAutoCommit(false);
		PreparedStatement ps1=con.prepareStatement("delete from associate where associateID=?");
		ps1.setInt(1, associateId);
		ps1.executeUpdate();
		con.commit();
		return true;
		
	} catch (SQLException e) {
		con.rollback();
		throw e;
	}
	
	finally {
		con.setAutoCommit(true);
	}

	}
	@Override
	public Associate getAssociate(int associateId) throws SQLException {
		
		PreparedStatement pstmt1=con.prepareStatement("SELECT   a.associateID,a.yearlyInvestmentUnder80C,a.firstName,a.lastName,a.department,a.designation,a.pancard,a.emailId,\r\n" + 
				"	b.basicSalary,b.hra,b.conveyenceAllowance,b.otherAllowance,b.personalAllowance,b.monthlyTax,b.epf,b.companyPf,b.gratuity,b.grossSalary,b.netSalary,\r\n" + 
				"	c.accountNumber,c.bankName,c.ifscCode\r\n" + 
				"FROM	associate a INNER JOIN salary b INNER JOIN  bankdetails c\r\n" + 
				"ON	a.associateID=b.associateID AND	a.associateID=c.associateID where a.associateID=?;");
		pstmt1.setInt(1, associateId);
		ResultSet rs=pstmt1.executeQuery();
		if(rs.next()) {
			return new Associate(rs.getInt("associateId"), rs.getInt("yearlyInvestmentUnder80C"),  rs.getString("firstName"), rs.getString("lastName"), rs.getString("department"), rs.getString("designation"), rs.getString("pancard"), rs.getString("emailId"),new Salary(rs.getFloat("basicSalary"), rs.getFloat("hra"), rs.getFloat("conveyenceAllowance"), rs.getFloat("otherAllowance"), rs.getFloat("personalAllowance"), rs.getFloat("monthlyTax"), rs.getFloat("epf"), rs.getFloat("companyPf"), rs.getFloat("gratuity"), rs.getFloat("grossSalary"), rs.getFloat("netSalary")), new BankDetails(rs.getInt("accountNumber"), rs.getString("bankName"), rs.getString("ifscCode")));
		}
		
	  return null;
 }
		
	


	@Override
	public List<Associate> getAssociates() throws SQLException {
		PreparedStatement pstmt1=con.prepareStatement("SELECT   a.associateID,a.yearlyInvestmentUnder80C,a.firstName,a.lastName,a.department,a.designation,a.pancard,a.emailId,\r\n" + 
				"	b.basicSalary,b.hra,b.conveyenceAllowance,b.otherAllowance,b.personalAllowance,b.monthlyTax,b.epf,b.companyPf,b.gratuity,b.grossSalary,b.netSalary,\r\n" + 
				"	c.accountNumber,c.bankName,c.ifscCode\r\n" + 
				"FROM	associate a INNER JOIN salary b INNER JOIN  bankdetails c\r\n" + 
				"ON	a.associateID=b.associateID AND	a.associateID=c.associateID ;");
	
		ResultSet rs=pstmt1.executeQuery();
		ArrayList<Associate> associate=new ArrayList<>();
		while(rs.next()) {
			associate.add(new Associate(rs.getInt("associateId"), rs.getInt("yearlyInvestmentUnder80C"),  rs.getString("firstName"), rs.getString("lastName"), rs.getString("department"), rs.getString("designation"), rs.getString("pancard"), rs.getString("emailId"),new Salary(rs.getFloat("basicSalary"), rs.getFloat("hra"), rs.getFloat("conveyenceAllowance"), rs.getFloat("otherAllowance"), rs.getFloat("personalAllowance"), rs.getFloat("monthlyTax"), rs.getFloat("epf"), rs.getFloat("companyPf"), rs.getFloat("gratuity"), rs.getFloat("grossSalary"), rs.getFloat("netSalary")), new BankDetails(rs.getInt("accountNumber"), rs.getString("bankName"), rs.getString("ifscCode"))));
		}
		
				
		return associate;


	}

}