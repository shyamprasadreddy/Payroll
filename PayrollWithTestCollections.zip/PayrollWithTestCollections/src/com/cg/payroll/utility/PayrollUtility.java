package com.cg.payroll.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class PayrollUtility {
	//public static int ASSOCIATE_ID_COUNTER=111;
	private static Connection con=null;
	public static Connection getDBConnection() throws FileNotFoundException, IOException, ClassNotFoundException, SQLException {
		if (con==null) {
			Properties properties=new Properties();
			properties.load(new FileInputStream(new File(".//resource//payroll.properties")));
			Class.forName(properties.getProperty("driver"));
			con=DriverManager.getConnection(properties.getProperty("url"), properties.getProperty("user"), "");
		}
		return con;
	}
}

