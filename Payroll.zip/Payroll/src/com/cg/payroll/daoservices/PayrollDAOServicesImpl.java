package com.cg.payroll.daoservices;
import com.cg.payroll.beans.Associate;
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	private static Associate []associateList = new Associate[10];
	private static int ASSOCIATE_ID_COUNTER=111;
	private static int ASSOCIATE_IDX_COUNTER=0;
	@Override
	public int insertAssociate(Associate associate) {
		if(ASSOCIATE_IDX_COUNTER>=0.7*associateList.length) {
			Associate []temp=new Associate[associateList.length+10];
			System.arraycopy(associateList, 0, temp, 0, associateList.length);
			associateList=temp;
		}
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associateList[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateID();
	}
	@Override
	public boolean updateAssociate(Associate associate) {
		for(int i=0;i<associateList.length;i++) 
			if(associateList!=null&&associateList[i].getAssociateID() == associate.getAssociateID()) {
				associateList[i]=associate;
				return true;
			}
		return false;
	}
	@Override
	public boolean deleteAssociate(int associateId) {
		for(int i=0;i<associateList.length;i++)
			if(associateList!=null&&associateList[i].getAssociateID()==associateId) {
				associateList[i]=null;	
				for(int k=i;k<associateList.length;k++)
					if(associateList[k+1]!=null && k+1<associateList.length)
						associateList[k]=associateList[k+1];	
				ASSOCIATE_IDX_COUNTER--;
				return true;
			}
		return false;
	}
	@Override
	public Associate getAssociate(int associateId) {
		for (Associate associate : associateList) 
			if(associateList!=null&&associate.getAssociateID()==associateId)
				return associate;
		return null;
	}
	@Override
	public Associate[] getAssociates() {
		return associateList;
	}
}
