package com.cg.payroll.exceptions;

public class PayrollServicesDownException extends Exception {
	
}
