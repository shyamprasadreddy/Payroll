
package com.cg.payroll.main;
import java.util.Scanner;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args) {
		try {
			PayrollServices payrollServices = new PayrollServicesImpl();
			PayrollDAOServices daoServices= new PayrollDAOServicesImpl();
		Scanner  scanner=new Scanner(System.in);
		System.out.println("Enter key 1.Insert 2.Update 3.Delete");
		int n=scanner.nextInt();
		//String =scanner.next();
		int associateId=payrollServices.acceptAssociateDetails("shyam", "prasad", "asdf", "asd", "asd45", "zxcv@gm.com",40000,600000,12000, 12000, 12345, "hdfc", "asdf2");
		switch(n) {
		case 1:	
				
				payrollServices.calculateNetSalary(associateId);
			break;
		case 2:	daoServices.deleteAssociate(associateId);
			break;
		default: 	System.out.println("only 1,2,3");	
			break;
		}
		}
		/*try {
		PayrollServices payrollServices = new PayrollServicesImpl();
		//Associate associate= new Associate();
		int associateId=payrollServices.acceptAssociateDetails("shyam", "prasad", "asdf", "asd", "asd45", "zxcv@gm.com",40000,600000,12000, 12000, 12345, "hdfc", "asdf2");
		payrollServices.calculateNetSalary(associateId);
		System.out.println(associateId);
		System.out.println(payrollServices.getAssociateDetails(associateId).getSalary().getPersonalAllowance());
		System.out.println("Monthly Net salary:" + payrollServices.calculateNetSalary(associateId)/12);
		System.out.println("Monthly Tax:" + payrollServices.getAssociateDetails(associateId).getSalary().getMonthlyTax());					
		} */
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
		




