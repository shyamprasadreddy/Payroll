package com.cg.payroll.main;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.services.PayrollServicesImpl;
 

public class MainClass {
	public static void main(String[] args) {
		PayrollServicesImpl payrollServices = new PayrollServicesImpl(); 
		//Given annual basic salary
		int associateId=payrollServices.acceptAssociateDetails("shyam", "prasad", "asdf", "asd", "asd45", "zxcv@gm.com",40000,600000,12000, 12000, 12345, "hdfc", "asdf2");
		System.out.println(associateId);
		System.out.println(payrollServices.getAssociateDetails(associateId).getFirstName());
		System.out.println("Annual Net salary:" + payrollServices.calculateNetSalary(associateId));
		System.out.println("Monthly Tax:" + payrollServices.getAssociateDetails(associateId).getSalary().getMonthlyTax());
	}
}
		




